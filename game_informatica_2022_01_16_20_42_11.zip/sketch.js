var ballx = 300; 
var bally = 300;
var ballSize = 25;
var score =0;
var gameState = "lvl 1"

function setup() {
  createCanvas(600,600);
  textAlign(CENTER);
}

function draw() {
  background(220)

  if(gameState == "lvl 1"){
  
    levelOne();
  }
  if(gameState == "lvl 2"){
    levelTwo();
  }
  if(gameState == "lvl 3"){
    levelThree()
  }
  if(gameState == "lvl 4"){
    levelFour();
  }
  
  text(("score: " + score),50,50) 
  text(("highscore: " + score), 650, 50)
 
  // objectives need to change but it doesnt work just like the levels. 
// timer if possible
}

function levelOne(){
  text("lvl 1", width/2, height-550);
  textSize(20)
  text(("objective: get to 2000 score"),130, 100);
  
  var distToBall = dist(ballx, bally, mouseX, mouseY);
  
  ellipse(ballx, bally, ballSize, ballSize)
  
  if(distToBall < ballSize*2){
    ballx = random(width);
    bally = random(height);
    score = score + 50;
    if(score>= 2000){
      gameState = "lvl 2";
    }
  }
} // end of level 1 

function levelTwo(){
  text("lvl 2", width/2, height-550);
  textSize(20)
  text(("objective: get to 3000 score"),130, 100);
  
  var distToBall = dist(ballx, bally, mouseX, mouseY);
  
  ellipse(ballx, bally, ballSize, ballSize)
  
  if(distToBall < ballSize/1){
    ballx = random(width);
    bally = random(height);
    score = score + 50;
    if(score>= 3000){
      gameState = "lvl 3";
    }
  }
} // end of level 2

function levelThree(){
    text("lvl 3", width/2, height-550);
  textSize(20)
  text(("objective: get to 5000 score"),130, 100);
  var distToBall = dist(ballx, bally, mouseX, mouseY);
  
  ellipse(ballx, bally, ballSize, ballSize)
  
  if(distToBall < ballSize/1){
    ballx = random(width);
    bally = random(height);
    score = score + 50;
    if(score>= 5000){
      levelThree()
    }
  }
} // end of level 3

function levelFour(){
    text("lvl 4", width/2, height-550);
  textSize(20)
  text(("objective: get to 5000 score"),130, 100);
  var distToBall = dist(ballx, bally, mouseX, mouseY);
  
  ellipse(ballx, bally, ballSize, ballSize/1.5)
  
  if(distToBall < ballSize/2){
    ballx = random(width);
    bally = random(height);
    score = score + 50;
    if(score>= 10000){
      levelFour()
    }
  }
} // end of level 4
// ENDING DOESNT WORK!!! WILL BE FIXED 

// Import the functions you need from the SDKs you need
/sketch.js:113:1 import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDOZuiol2qFZ2G1_uOdelT9CFfm3xo8kKI",
  authDomain: "p5js-game.firebaseapp.com",
  projectId: "p5js-game",
  storageBucket: "p5js-game.appspot.com",
  messagingSenderId: "923138559958",
  appId: "1:923138559958:web:afe5f161c223b0adb71e77",
  measurementId: "G-0DC48YWZ2M"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);


